package com.icss.dao;

import com.icss.entity.Admin;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface AdminDao {
    //查询管理员
    Admin seladmin(Admin admin);
    //添加管理员
    int addadmin(Admin adnim);
    //管理员登陆后根据aid修改自己信息
    int updateadmin(Admin adnim);

    List<Admin> findAdmin(String aname);
}
