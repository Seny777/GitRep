package com.icss.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.icss.dao.GoodsDao;
import com.icss.entity.Goods;
import com.icss.entity.GoodsType;
import com.icss.entity.ResultInfo;
import com.icss.service.GoodsService;
import com.icss.service.GoodsTypeService;
import com.sun.org.apache.bcel.internal.generic.RETURN;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/goodstype/")
public class GoodsTypeController {
    @Autowired
    private GoodsTypeService goodsTypeService;
    @Autowired
    private GoodsService goodsService;

    //删除商品种类
    @RequestMapping("deleteGoodsType.do")
    @ResponseBody
    public ResultInfo deleteGoodType(@RequestParam("gtids")String gtids){
        List<Goods> goods=goodsService.findGoodsByGtids(gtids);
        if (goods==null||goods.size()==0){
            int x=goodsTypeService.deleteGoodsType(gtids);
            return x>0?new ResultInfo("删除成功", true):new ResultInfo("删除失败", false);
        }else{
            return new ResultInfo("删除的分类下还有商品，请重新选择!", false);
        }

    }

    //添加商品种类
    @RequestMapping("addGoodsType.do")
    @ResponseBody
    public ResultInfo addGoodsType(GoodsType goodsType){
      int addGoodsType=goodsTypeService.addGoodsType(goodsType);
        return addGoodsType> 0 ? new ResultInfo("添加成功", true) : new ResultInfo("添加失败", false);
    }

    //查询所有商品种类
    @RequestMapping("findAllGoodsType.do")
    public String findAllGoodsType(Model model,@RequestParam(value = "pageNum", defaultValue = "1")Integer pageNum){
        Map<String, Object> map = new HashMap<>();
        map.put("pageNum", pageNum);
        PageHelper.startPage(pageNum,10);
        List<GoodsType> typeList=goodsTypeService.findAllGoodsType();
        PageInfo<GoodsType> page = new PageInfo<GoodsType>(typeList);
        model.addAttribute("map", map);
        model.addAttribute("page", page);
        return "goodstype";
    }
}
