package com.icss.controller;

import com.icss.entity.PathInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Arrays;

@Controller
@RequestMapping("/kz/")
public class KzController {
	@RequestMapping("tz.do")
	@ResponseBody
	public PathInfo tz(@Param("ym") String ym){
		String[] home={"首页","首","页","返回","返","回","回退","退"};
		String[] ty={"种类","类","分类","分","种"};
		String[] info={"信息","商品","商","品","信","息"};
		String[] order={"订单","单","单子","订"};
		String[] user={"用户","管理","用","户"};
		if (ym==null||ym.length()<=0){
			return new PathInfo("http://192.168.3.107/page/404.jsp");
		}else if(Arrays.asList(home).contains(ym)){
			return new PathInfo("http://192.168.3.107/page/home.jsp");
		}else if(Arrays.asList(ty).contains(ym)){
			return new PathInfo("http://192.168.3.107/page/goodstype.jsp");
		}else if(Arrays.asList(info).contains(ym)){
			return new PathInfo("http://192.168.3.107/page/goods.jsp");
		}else if(Arrays.asList(order).contains(ym)){
			return new PathInfo("http://192.168.3.107/page/order.jsp");
		}else if(Arrays.asList(user).contains(ym)){
			return new PathInfo("http://192.168.3.107/page/user.jsp");
		}else{
			return new PathInfo("http://192.168.3.107/page/404.jsp");
		}
	}
}
