package com.icss.controller;

import com.icss.entity.Admin;
import com.icss.entity.ResultInfo;
import com.icss.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/admin/")
public class AdminController {
    @Autowired
    private AdminService adminService;
    @RequestMapping("toindex.do")
    public String toindex(){
        return "index";
    }
    @RequestMapping("jy.do")
    @ResponseBody
    public ResultInfo findAdmin(String aname){
        List<Admin> list=adminService.findAdmin(aname);
        return list.size()>0?new ResultInfo(false):new ResultInfo(true);
    }
    
    //登录时查询是否有此管理员匹配的账号密码，是则成功
    @RequestMapping("login.do")
    @ResponseBody
    public ResultInfo seladmin(HttpServletRequest req, Admin admin, Model model) {
        Admin login=adminService.seladmin(admin);
        if (login!=null){
            req.getSession().setAttribute("admin",login);
            model.addAttribute("admin",login);
            return new ResultInfo("登录成功",true);
        }else{
            return new ResultInfo("用户名或密码错误",false);
        }
    }
    @RequestMapping("tologin.do")
    public String tologin(HttpServletRequest req){
        HttpSession session = req.getSession();
        session.removeAttribute("admin");
        session.invalidate();
        return "login";
    }
    
    //添加管理员,添加成功跳转到登录页面失败留在注册页面
    @RequestMapping("reg.do")
    @ResponseBody
    public ResultInfo addadmin(Admin admin){
        int i=adminService.addadmin(admin);
        return i>0?new ResultInfo("注册成功",true):new ResultInfo("注册失败",false);
    }
    
    
    //管理员登陆后根据aid修改自己信息,修改成功跳转到登录页面失败留在本页面
    @RequestMapping("updateadmin.do")
    @ResponseBody
    public ResultInfo updateadmin(Admin admin, HttpSession session, @RequestParam("cpwd2")String cpwd2){
        //查询输入的账号密码是否匹配存在
        Admin user=adminService.seladmin(admin);
        System.out.println(user+"__"+cpwd2);
        if (user!=null){
            //存在-->根据id修改
            int i=adminService.updateadmin(new Admin(user.getAid(),cpwd2));
            return i>0?new ResultInfo("注册成功",true):new ResultInfo("注册失败",false);
        }else {
            //不存在
            return  new ResultInfo("账号或密码错误",false);
        }
    }
}
