package com.icss.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.icss.entity.*;
import com.icss.service.GoodsService;
import com.icss.service.GoodsTypeService;
import com.icss.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping("/goods/")
public class GoodsController {
	@Autowired
	private GoodsService goodsService;
	@Autowired
	private GoodsTypeService goodsTypeService;
	@Autowired
	private OrderService orderService;

	@RequestMapping("findCount.do")
	@ResponseBody
	public Integer findCount(){
		return goodsService.findCount();
	}
	//删除商品
	@RequestMapping("deleteGoods.do")
	@ResponseBody
	public ResultInfo deleteGoods(@RequestParam("gids")String gids){
		System.out.println(gids);
		List<Goods> goods=goodsService.findGoodsByGids(gids);//调用根据商品编号gids查询商品的方法
		List<OrderList> orderList=orderService.findAllByGids(gids);
		int x=0;
		for (Goods g:goods) {
			if(g.getSynum()!=0){
				x=1;
			}
		}
		if(orderList.size()>0){
			x=2;
		}
		if(x==0){
			int z=goodsService.deleteGoods(gids);
			return z>0?new ResultInfo("删除成功!",true):new ResultInfo("删除失败!",false);
		}else if(x==1){
			return new ResultInfo("你选中的商品中还有剩余库存,不能删除", false);
		}
		return new ResultInfo("你选中的商品中还有订单未删除,不能删除", false);
	}

	//修改商品功能
	@RequestMapping("updateGoods.do")
	@ResponseBody
	public ResultInfo updateGoods(Goods goods) {
		int x=goodsService.updateGoods(goods);
		return x>0?new ResultInfo("修改成功!",true):new ResultInfo("修改失败!",false);//响应重定向
	}

	//根据商品编号找到该商品实现数据回显功能
	@RequestMapping("findGoodsByGid.do")
	@ResponseBody
	public Goods findGoodsByGid(@RequestParam("gid")Integer gid){
		return goodsService.findGoodsByGid(gid);
	}


	//添加商品
	@RequestMapping("addGoods.do")
	public String addGoods(Goods goods, Model model, @RequestParam("filename") MultipartFile file, HttpServletRequest req) throws IOException {
		Date date=new Date();//写一个Date对象
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//日期格式化
		String time=sdf.format(date);//获取当前时间
		Timestamp gtime= Timestamp.valueOf(time);//将Date类型日期转换成Timestamp类型日期
		goods.setGtime(gtime);//将日期传值给goods
		//System.out.println(goods);
		//获取文件真实路径
		String path=req.getServletContext().getRealPath("/image/");
		System.out.println(path);
		//判断文件不能为空
		if (!file.isEmpty()) {
			//获取上传文件的名称，而且文件名不能重复
			String filename = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
			System.out.println(filename);
			goods.setGimg(filename);
			//保存文件
			file.transferTo(new File(path, filename));
		}
		int addGoods= goodsService.addGoods(goods);
		return addGoods > 0 ? "redirect:findAllGoods.do":"redirect:toaddGoods.do";//响应重定向
	}

	//查询所有商品
	@RequestMapping("findAllGoods.do")
	public String findAllGoods(Model model,
							   @RequestParam(value = "gname",defaultValue = "")String gname,
							   @RequestParam(value = "pageNum", defaultValue = "1")Integer pageNum){
		//写一个Map集合
		Map<String,Object> map=new HashMap<String,Object>();
		//把数据存放到map中
		map.put("gname", gname);
		map.put("pageNum", pageNum);
		//使用PageHelper实现分页
		PageHelper.startPage(pageNum, 8);
		List<GoodsVo> goodsList=goodsService.findAllGoods(map);
		//System.out.println(map);
		//写一个PageInfo对象
		PageInfo<GoodsVo> page = new PageInfo<GoodsVo>(goodsList);
		List<GoodsType> typeList=goodsTypeService.findAllGoodsType();//实现商品种类下拉框
		model.addAttribute("list",typeList);
		model.addAttribute("page", page);
		model.addAttribute("map",map);
		return "goods";
	}
}


