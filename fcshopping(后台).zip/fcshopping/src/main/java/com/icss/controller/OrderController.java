package com.icss.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.icss.entity.*;
import com.icss.service.OrderService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/order/")
public class OrderController {

    @Autowired
    private OrderService orderService;
    @RequestMapping("findCount.do")
    @ResponseBody
    public Integer findCount(){
        return orderService.findCount();
    }
    //删除订单
    @RequestMapping("deleteOrderByOid.do")
    @ResponseBody
    public ResultInfo deleteOrderByOid(@RequestParam("oids")String oids) {
        int i=orderService.deleteOrderByOid(oids);
        return i>0?new ResultInfo("删除成功",true):new ResultInfo("删除失败",false);
    }

    //购物车结算
    @RequestMapping("updateCartOrderByOid.do")
    @ResponseBody
    public ResultInfo updateCartOrderByOid(@RequestParam("oids")String oids){
        int i = orderService.updateCartOrderByOid(oids);
        return i>0?new ResultInfo("结算成功",true):new ResultInfo("结算失败",false);
    }

    //修改购物车商品数量
    @RequestMapping("updateCartOrderListByOid.do")
    @ResponseBody
    public ResultInfo updateCartOrderListByOid(OrderVoCart orderVoCart){
        //获取总价
        orderVoCart.setSprice(orderVoCart.getOlnum()*orderVoCart.getGprice());
        int i=orderService.updateCartOrderListByOid(orderVoCart);
        return i>0?new ResultInfo("修改成功",true):new ResultInfo("修改失败",false);
    }

    //用户查询购物车
    @RequestMapping("findOrderByUid.do")
    @ResponseBody
    public Object findOrderByUid(Model model,
        @RequestParam(value="uid",defaultValue = "")Integer uid,
        @RequestParam(value="pageNum",defaultValue = "1")Integer pageNum){
        //实现分页
        PageHelper.startPage(pageNum,5);
        //购物车信息
        List<OrderVoCart> cartlist = orderService.findOrderByUid(uid);
        //写一个PageInfo对象
        PageInfo page=new PageInfo(cartlist);
        //将信息写入Model层
        model.addAttribute("pageNum",pageNum);
        model.addAttribute("cartlist",cartlist);
        model.addAttribute("page",page);
        return cartlist;
    }

    //后台发货
    @RequestMapping("updateOrderByOid.do")
    @ResponseBody
    public ResultInfo updateOrderByOid(@RequestParam("oid")Integer oid){
        Order order=new Order();
        order.setOid(oid);
        //获取发货时间
        Date date =new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp dtime=Timestamp.valueOf(sdf.format(date));
        order.setDtime(dtime);
        //确定发货
        int i =orderService.updateOrderByOid(order);
        return i>0?new ResultInfo("发货成功",true):new ResultInfo("发货失败",false);
    }

    //查询所有订单
    @RequestMapping("findAllOrder.do")
    public String findAllOrder(Model model,
        @RequestParam(value="username",defaultValue = "")String username,
        @RequestParam(value="ispay",defaultValue = "")String ispay,
        @RequestParam(value="pageNum",defaultValue = "1")Integer pageNum){
        //写一个map集合
        Map<String,Object> map=new HashMap<>();
        //将数据放入map集合中
        if(ispay.equals("已付款")){
            ispay="是";
        }else if(ispay.equals("未付款")){
            ispay="否";
        }
        map.put("username",username);
        map.put("ispay",ispay);
        map.put("pageNum",pageNum);
        //实现分页
        PageHelper.startPage(pageNum,8);
        //查询所有订单信息
        List<OrderVo> orderlist=orderService.findAllOrder(map);
        //写一个PagrInfo对象
        PageInfo<OrderVo> page=new PageInfo<>(orderlist);
        //将数据写入Model层
        model.addAttribute("page",page);
        model.addAttribute("map",map);
        return "order";
    }

    //订单生成
    @RequestMapping("addOrder.do")
    @ResponseBody
    public ResultInfo addOrder(Order order, HttpServletRequest req,@RequestParam("olnum") Integer olnum,@RequestParam("gid")Integer gid){
        //获取订单信息
        Date date=new Date();
        SimpleDateFormat onumdate = new SimpleDateFormat("yyyyMMddHHmmss");
        //订单序号
        String onum="FC"+"001"+onumdate.format(date);
        //用户编号
        User user=(User)req.getSession().getAttribute("user");
        Integer uid=user.getUid();
        SimpleDateFormat stimedate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //提交订单时间
        Timestamp stime= Timestamp.valueOf(stimedate.format(date));
        //买家收货地址
        String uaddress=user.getUaddress();
        order.setOnum(onum);
        order.setUid(uid);
        order.setStime(stime);
        order.setUaddress(uaddress);
        order.setIssend("否");
        //写一个OrderList对象
        OrderList orderList=new OrderList(gid,olnum);
        int i =orderService.addOrder(order,orderList);
        return i>0?new ResultInfo("添加订单成功",true):new ResultInfo("添加订单失败",false);
    }

}
