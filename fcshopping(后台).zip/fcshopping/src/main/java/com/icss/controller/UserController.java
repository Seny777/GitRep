package com.icss.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.icss.entity.ResultInfo;
import com.icss.entity.User;
import com.icss.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping ("/user/")
public class UserController {
    @Autowired
    private UserService userService;
    //实现注册功能
    @RequestMapping("add.do")
    @ResponseBody
    private ResultInfo addUser(User user){
        //获取时间
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        java.sql.Date regtime= java.sql.Date.valueOf(sdf.format(date));
        user.setRegtime(regtime);
        int add= userService.addUser(user);
        return add>0?new ResultInfo("添加成功",true):new ResultInfo("添加失败",false);
    }

    //实现回显功能
    @RequestMapping("findUserByUsername.do")
    @ResponseBody
    public User findUserByUsername(@RequestParam("uid") Integer uid){
       return userService.findUserById(uid);
    }

    //实现删除功能
    @RequestMapping("delete.do")
    @ResponseBody
    public ResultInfo deleteUser(@RequestParam("uids")String uids){
        int delete= userService.deleteUser(uids);
        return delete>0?new ResultInfo("删除成功",true):new ResultInfo("删除失败",false);
    }

    //查询所有用户
    @RequestMapping("findAllUser.do")
    public String findAllUser(Model model,@RequestParam(value = "pageNum", defaultValue = "1")Integer pageNum){
        Map<String, Object> map = new HashMap<>();
        map.put("pageNum", pageNum);
        PageHelper.startPage(pageNum,10);
        List<User> userList=userService.findAllUser();
        PageInfo<User> page = new PageInfo<User>(userList);
        model.addAttribute("map", map);
        model.addAttribute("page", page);
        return "user";
    }

    @RequestMapping("findCount.do")
    @ResponseBody
    public Integer findCount(){
        return userService.findCount();
    }
}
