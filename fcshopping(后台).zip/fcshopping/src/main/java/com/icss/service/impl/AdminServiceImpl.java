package com.icss.service.impl;

import com.icss.entity.Admin;
import com.icss.dao.AdminDao;
import com.icss.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminDao adminDao;
    @Override
    public Admin seladmin(Admin admin) {
        return adminDao.seladmin(admin);
    }
    
    @Override
    public int addadmin(Admin admin) {
        return adminDao.addadmin(admin);
    }
    
    @Override
    public int updateadmin(Admin adnim) {
        return adminDao.updateadmin(adnim);
    }

    @Override
    public List<Admin> findAdmin(String aname) {
        return adminDao.findAdmin(aname);
    }
}
