package com.icss.service;

import com.icss.entity.Admin;

import java.util.List;

public interface AdminService {
    //查询管理员
    Admin seladmin(Admin admin);
    //添加管理员
    int addadmin(Admin adnim);
    //管理员登陆后根据aid修改自己信息
    int updateadmin(Admin adnim);
    
    List<Admin> findAdmin(String aname);
}
