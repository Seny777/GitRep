package com.icss.service.impl;

import com.icss.dao.OrderDao;
import com.icss.entity.Order;
import com.icss.entity.OrderList;
import com.icss.entity.OrderVo;
import com.icss.entity.OrderVoCart;
import com.icss.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderDao orderDao;

    //删除订单
    @Override
    public int deleteOrderByOid(String oids) {
        int x=orderDao.deleteOrderListByOid(oids);
        if(x>0){
            return orderDao.deleteOrderByOid(oids);
        }
        return 0;
    }

    //购物车结算
    @Override
    public int updateCartOrderByOid(String oids) {
        return orderDao.updateCartOrderByOid(oids);
    }

    //修改购物车商品数量
    @Override
    public int updateCartOrderListByOid(OrderVoCart orderVoCart) {
        return orderDao.updateCartOrderListByOid(orderVoCart);
    }

    //查询购物车
    @Override
    public List<OrderVoCart> findOrderByUid(Integer uid) {
        return orderDao.findOrderByUid(uid);
    }

    //后台修改订单
    @Override
    public int updateOrderByOid(Order order) {
        return orderDao.updateOrderByOid(order);
    }

    //查询所有订单
    @Override
    public List<OrderVo> findAllOrder(Map<String, Object> map) {
        return orderDao.findAllOrder(map);
    }

    //订单生成
    @Override
    public int addOrder(Order order,OrderList orderList) {
        int i=orderDao.addOrder(order);
        if(i>0){
           orderList.setOid(order.getOid());
           return orderDao.addOrderList(orderList);
        }
        return 0;
    }

    @Override
    public Integer findCount() {
        return orderDao.findCount();
    }

    @Override
    public List<OrderList> findAllByGids(String gids) {
        return orderDao.findAllByGids(gids);
    }
}
