package com.icss.service.impl;

import com.icss.dao.GoodsTypeDao;
import com.icss.entity.GoodsType;
import com.icss.service.GoodsTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GoodsTypeServiceImpl implements GoodsTypeService {
    @Autowired
    private GoodsTypeDao goodsTypeDao;


    //删除商品种类
    @Override
    public int deleteGoodsType(String gtids) {
        return goodsTypeDao.deleteGoodsType(gtids);
    }

    //添加商品种类
    @Override
    public int addGoodsType(GoodsType goodsType) {
        return goodsTypeDao.addGoodsType(goodsType);
    }

    //查询所有商品种类
    @Override
    public List<GoodsType> findAllGoodsType() {
        return goodsTypeDao.findAllGoodsType();
    }
}
