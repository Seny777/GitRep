package com.icss.entity;

public class PathInfo {
	String pathinfo;

	public PathInfo(String pathinfo) {
		this.pathinfo = pathinfo;
	}

	public String getPathinfo() {
		return pathinfo;
	}

	public void setPathinfo(String pathinfo) {
		this.pathinfo = pathinfo;
	}

	public PathInfo() {
	}

	@Override
	public String toString() {
		return "PathInfo{" +
				"pathinfo='" + pathinfo + '\'' +
				'}';
	}
}
