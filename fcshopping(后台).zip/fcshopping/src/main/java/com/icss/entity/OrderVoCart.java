package com.icss.entity;

import java.io.Serializable;

public class OrderVoCart implements Serializable {

    private Integer oid;  //订单编号
    private String gname;   //商品名称
    private String ginfo;   //商品信息
    private double gprice;  //商品单价
    private Integer olnum;  //商品数量
    private double sprice;  //总价

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGinfo() {
        return ginfo;
    }

    public void setGinfo(String ginfo) {
        this.ginfo = ginfo;
    }

    public double getGprice() {
        return gprice;
    }

    public void setGprice(double gprice) {
        this.gprice = gprice;
    }

    public Integer getOlnum() {
        return olnum;
    }

    public void setOlnum(Integer olnum) {
        this.olnum = olnum;
    }

    public double getSprice() {
        return sprice;
    }

    public void setSprice(double sprice) {
        this.sprice = sprice;
    }

    public OrderVoCart(Integer oid, String gname, String ginfo, double gprice, Integer olnum, double sprice) {
        this.oid = oid;
        this.gname = gname;
        this.ginfo = ginfo;
        this.gprice = gprice;
        this.olnum = olnum;
        this.sprice = sprice;
    }

    public OrderVoCart() {
    }

    @Override
    public String toString() {
        return "OrderVoCart{" +
                "oid=" + oid +
                ", gname='" + gname + '\'' +
                ", ginfo='" + ginfo + '\'' +
                ", gprice=" + gprice +
                ", olnum=" + olnum +
                ", sprice=" + sprice +
                '}';
    }
}
