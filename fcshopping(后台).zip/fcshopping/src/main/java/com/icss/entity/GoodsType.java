package com.icss.entity;

import java.io.Serializable;

public class GoodsType implements Serializable {
    private Integer gtid;//商品种类编号
    private String gtname;//商品种类名称

    public Integer getGtid() {
        return gtid;
    }

    public void setGtid(Integer gtid) {
        this.gtid = gtid;
    }

    public String getGtname() {
        return gtname;
    }

    public void setGtname(String gtname) {
        this.gtname = gtname;
    }

    public GoodsType(Integer gtid, String gtname) {
        this.gtid = gtid;
        this.gtname = gtname;
    }

    public GoodsType() {

    }

    public GoodsType(String gtname) {
        this.gtname = gtname;
    }

    @Override
    public String toString() {
        return "GoodsType{" +
                "gtid=" + gtid +
                ", gtname='" + gtname + '\'' +
                '}';
    }
}
