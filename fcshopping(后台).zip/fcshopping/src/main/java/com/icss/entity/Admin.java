package com.icss.entity;

import java.io.Serializable;

public class Admin implements Serializable {
    private int aid;
    private String aname;
    private String apassword;
    private static final long serialVersionUID = 1L;
    
    public int getAid() {
        return aid;
    }
    
    public void setAid(int aid) {
        this.aid = aid;
    }
    
    public String getAname() {
        return aname;
    }
    
    public void setAname(String aname) {
        this.aname = aname;
    }
    
    public String getApassword() {
        return apassword;
    }
    
    public void setApassword(String apassword) {
        this.apassword = apassword;
    }
    
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    
    public Admin(int aid, String aname, String apassword) {
        this.aid = aid;
        this.aname = aname;
        this.apassword = apassword;
    }
    
    public Admin(String aname, String apassword) {
        this.aname = aname;
        this.apassword = apassword;
    }
    
    public Admin() {
    }
    
    public Admin(int aid, String apassword) {
        this.aid = aid;
        this.apassword = apassword;
    }
    
    @Override
    public String toString() {
        return "Admin{" +
                "aid=" + aid +
                ", aname='" + aname + '\'' +
                ", apassword='" + apassword + '\'' +
                '}';
    }
}
