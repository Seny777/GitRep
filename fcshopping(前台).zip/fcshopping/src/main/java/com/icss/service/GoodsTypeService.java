package com.icss.service;

import com.icss.entity.GoodsType;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GoodsTypeService {
    //删除商品种类
    int deleteGoodsType(String gtids);
    //添加商品种类
    int addGoodsType(GoodsType goodsType);
    //查询所有商品种类
    List<GoodsType> findAllGoodsType();
}
