package com.icss.service.impl;

import com.icss.dao.UserDao;
import com.icss.entity.User;
import com.icss.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;
    //添加
    @Override
    public  int addUser(User user){
        return userDao.addUser(user);
    }
    //删除

    public  int deleteUser(String uids){
        return  userDao.deleteUser(uids);
    }

    @Override
    public User findUserById(Integer uid) {
        return userDao.findUserById(uid);
    }

    @Override
    public List<User> findAllUser() {
        return userDao.findAllUser();

    }

    @Override
    public Integer findCount() {
        return userDao.findCount();
    }

    @Override
    public User loginUser(User user) {
        return userDao.loginUser(user);
    }

    @Override
    public int updateUser(User user) {
        return userDao.updateUser(user);
    }

}
