package com.icss.service;

import com.icss.entity.Order;
import com.icss.entity.OrderList;
import com.icss.entity.OrderVo;
import com.icss.entity.OrderVoCart;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface OrderService {

    //删除订单
    int deleteOrderByOid(String oids);

    //购物车结算
    int updateCartOrderByOid(String oids);

    //修改购物车商品数量
    int updateCartOrderListByOid(OrderVoCart orderVoCart);

    //查询购物车
    List<OrderVoCart> findOrderByUid(Integer uid);

    //后台修改订单
    int updateOrderByOid(Order order);

    //查询所有订单
    List<OrderVo> findAllOrder(Map<String,Object> map);

    //订单生成
    int addOrder(Order order,OrderList orderList);

}
