package com.icss.service.impl;

import com.icss.dao.GoodsDao;
import com.icss.dao.OrderDao;
import com.icss.entity.*;
import com.icss.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private GoodsDao goodsDao;

    //删除订单
    @Override
    public int deleteOrderByOid(String oids) {
        int i=orderDao.deleteOrderListByOid(oids);
        return i>0?orderDao.deleteOrderByOid(oids):i;
    }

    //购物车结算
    @Override
    public int updateCartOrderByOid(String oids) {
        return orderDao.updateCartOrderByOid(oids);
    }

    //修改购物车商品数量
    @Override
    public int updateCartOrderListByOid(OrderVoCart orderVoCart) {
        return orderDao.updateCartOrderListByOid(orderVoCart);
    }

    //查询购物车
    @Override
    public List<OrderVoCart> findOrderByUid(Integer uid) {
        return orderDao.findOrderByUid(uid);
    }

    //后台修改订单
    @Override
    public int updateOrderByOid(Order order) {
        return orderDao.updateOrderByOid(order);
    }

    //查询所有订单
    @Override
    public List<OrderVo> findAllOrder(Map<String, Object> map) {
        return orderDao.findAllOrder(map);
    }

    //订单生成
    @Override
    public int addOrder(Order order,OrderList orderList) {
        int i=orderDao.addOrder(order);
        Goods goods=goodsDao.findGoodsByGid(orderList.getGid());
        goods.setSynum(goods.getSynum()-orderList.getOlnum());
        goodsDao.updateGoods(goods);
        if(i>0){
           return orderDao.addOrderList(new OrderList(order.getOid(),orderList.getGid(),orderList.getOlnum()));
        }
        return i;
    }
}
