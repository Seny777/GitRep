package com.icss.service;

import com.icss.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService {

    int addUser(User user);//实现添加用户功能

    int deleteUser(String uids);//实现用户删除功能

    User findUserById(Integer uid);//通过uid查询用户信息

    List<User> findAllUser();//查询所有用户
    //查询商品数量
    Integer findCount();

    User loginUser(User user);

    int updateUser(User user);
}
