package com.icss.service.impl;

import com.icss.dao.GoodsDao;
import com.icss.entity.Goods;
import com.icss.entity.GoodsVo;
import com.icss.service.GoodsService;
import com.icss.service.GoodsTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GoodsServiceImpl implements GoodsService {
    @Autowired
    private GoodsDao goodsDao;

    //根据商品种类编号gtid查询商品
    @Override
    public List<Goods> findGoodsByGtid(Integer gtid) {
        return goodsDao.findGoodsByGtid(gtid);
    }

    @Override
    public List<Goods> findGoodsByGtids(String gtids) {
        return goodsDao.findGoodsByGtids(gtids);
    }

    @Override
    public Integer findCount() {
        return goodsDao.findCount();
    }

    @Override
    public List<Goods> findGoodsByGids(String gids) {
        return goodsDao.findGoodsByGtids(gids);
    }

    @Override
    public int deleteGoods(String gids) {
        return goodsDao.deleteGoods(gids);
    }

    @Override
    public int updateGoods(Goods goods) {
        return goodsDao.updateGoods(goods);
    }

    @Override
    public Goods findGoodsByGid(Integer gid) {
        return goodsDao.findGoodsByGid(gid);
    }

    @Override
    public int addGoods(Goods goods) {
        return goodsDao.addGoods(goods);
    }

    @Override
    public List<GoodsVo> findAllGoods(Map<String, Object> map) {
        return goodsDao.findAllGoods(map);
    }
}
