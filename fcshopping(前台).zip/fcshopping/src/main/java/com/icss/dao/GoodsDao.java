package com.icss.dao;

import com.icss.entity.Goods;
import com.icss.entity.GoodsVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface GoodsDao {
    //根据商品种类编号gtid查询商品
    List<Goods> findGoodsByGtid(@Param("gtid") Integer gtid);

    //根据商品种类编号gtids查询商品
    List<Goods> findGoodsByGtids(@Param("gtids") String gtids);
    //查询商品数量
    Integer findCount();
    //根据商品编号gids查询商品
    List<Goods> findGoodsByGids(@Param("gids") String gids);
    //删除商品
    int deleteGoods(@Param("gids") String gids);
    //修改商品
    int updateGoods(Goods goods);
    //根据商品编号找到该商品实现数据回显功能
    Goods findGoodsByGid(@Param("gid") Integer gid);
    //添加商品
    int addGoods(Goods goods);
    //查询所有商品
    List<GoodsVo> findAllGoods(Map<String, Object> map);
}
