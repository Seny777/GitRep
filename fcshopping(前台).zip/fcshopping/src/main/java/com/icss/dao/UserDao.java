package com.icss.dao;

import com.icss.entity.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserDao {

    int addUser(User user);//实现添加用户功能

    int deleteUser(String uids);//实现用户删除功能

    User findUserById(Integer uid);//通过uid查询用户信息

    List<User> findAllUser();//查询所有用户

    //查询商品数量
    Integer findCount();

    User loginUser(User user);

    int updateUser(User user);
}
