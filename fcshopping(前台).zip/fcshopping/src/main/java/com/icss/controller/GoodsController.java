package com.icss.controller;

import com.icss.entity.Goods;
import com.icss.entity.GoodsType;
import com.icss.entity.GoodsVo;
import com.icss.service.GoodsService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/goods/")
public class GoodsController {
    @Autowired
    private GoodsService goodsService;

    @RequestMapping("findAllGoods.do")
    public String tohome(Model model, @RequestParam(value="gname",defaultValue = "")String gname){
        //写一个map集合
        Map<String,Object> map=new HashMap<>();
        map.put("gname",gname);
        List<GoodsVo> list=goodsService.findAllGoods(map);
        model.addAttribute("list",list);
        model.addAttribute("map",map);
        return "home";
    }

    @RequestMapping("findGoods.do")
    public String togoodlist(Model model, @RequestParam(value="gname",defaultValue = "")String gname){
        //写一个map集合
        System.out.println(gname);
        Map<String,Object> map=new HashMap<>();
        map.put("gname",gname);
        List<GoodsVo> list=goodsService.findAllGoods(map);
        model.addAttribute("list",list);
        model.addAttribute("map",map);
        return "goodslist";
    }

    @RequestMapping("findGoodsByGid.do")
    public String findGoodsByGid(@Param("gid")Integer gid,Model model){
        Goods goods=goodsService.findGoodsByGid(gid);
        List<Goods> list=goodsService.findGoodsByGtid(goods.getGtid());
        model.addAttribute("list",list);
        model.addAttribute("goods",goods);
        return "goodsinfo";
    }

    @RequestMapping("findByGid.do")
    @ResponseBody
    public Goods findByGid(Integer gid){
        Goods goods=goodsService.findGoodsByGid(gid);
        return goods;
    }
}
