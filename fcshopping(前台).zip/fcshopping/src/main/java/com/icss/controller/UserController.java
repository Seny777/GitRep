package com.icss.controller;

import com.icss.entity.ResultInfo;
import com.icss.entity.User;
import com.icss.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
@RequestMapping("/user/")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("zx.do")
    public  String tologin(HttpServletRequest req){
        HttpSession session=req.getSession();
        session.removeAttribute("user");
        session.invalidate();
        return "login";
    }
    @RequestMapping("login.do")
    @ResponseBody
    public ResultInfo login(User user, HttpServletRequest req, Model model){
        User login=userService.loginUser(user);
        if(login!=null){
            req.getSession().setAttribute("user",login);
            model.addAttribute("user",login);
            return new ResultInfo("登录成功!",true);
        }else{
            return new ResultInfo("登录失败!",false);
        }
    }

    @RequestMapping("regUser.do")
    public String  addUser(User user){
        Date date=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp time=Timestamp.valueOf(sdf.format(date));
        user.setRegtime(time);
        int x=userService.addUser(user);
        if(x>0){
            return "redirect:/to/login.do";
        }else{
            return "redirect:/to/reg.do";
        }
    }

    @RequestMapping("updateUser.do")
    public  String updateUser(User user){
        int x=userService.updateUser(user);
        return  x>0?"redirect:/goods/findAllGoods.do":"userinfo";
    }

    @RequestMapping("gouserinfo.do")
    public  String gouserinfo(){
        return "userinfo";
    }
}
