package com.icss.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/to/")
public class toController {

    @RequestMapping("login.do")
    public String tologin(){
        return "login";
    }

    @RequestMapping("reg.do")
    public String toreg(){
        return "reg";
    }
}
