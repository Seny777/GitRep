package com.icss.entity;

import java.io.Serializable;
import java.util.Date;

public class GoodsVo implements Serializable {
    private Integer gid;//商品编号
    private String gname;//商品名称
    private String gtname;//商品种类名称
    private String gfactor;//生产厂家
    private String gimg;//商品图片
    private String ginfo;//商品描述
    private double gprice;//商品价格
    private double fprice;//帆成网价格(打折价)
    private Integer gnum;//商品总数量
    private Integer synum;//商品剩余数量
    private Date gtime;//商品上架上架

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGtname() {
        return gtname;
    }

    public void setGtname(String gtname) {
        this.gtname = gtname;
    }

    public String getGfactor() {
        return gfactor;
    }

    public void setGfactor(String gfactor) {
        this.gfactor = gfactor;
    }

    public String getGimg() {
        return gimg;
    }

    public void setGimg(String gimg) {
        this.gimg = gimg;
    }

    public String getGinfo() {
        return ginfo;
    }

    public void setGinfo(String ginfo) {
        this.ginfo = ginfo;
    }

    public double getGprice() {
        return gprice;
    }

    public void setGprice(double gprice) {
        this.gprice = gprice;
    }

    public double getFprice() {
        return fprice;
    }

    public void setFprice(double fprice) {
        this.fprice = fprice;
    }

    public Integer getGnum() {
        return gnum;
    }

    public void setGnum(Integer gnum) {
        this.gnum = gnum;
    }

    public Integer getSynum() {
        return synum;
    }

    public void setSynum(Integer synum) {
        this.synum = synum;
    }

    public Date getGtime() {
        return gtime;
    }

    public void setGtime(Date gtime) {
        this.gtime = gtime;
    }

    public GoodsVo(Integer gid, String gname, String gtname, String gfactor, String gimg, String ginfo, double gprice, double fprice, Integer gnum, Integer synum, Date gtime) {
        this.gid = gid;
        this.gname = gname;
        this.gtname = gtname;
        this.gfactor = gfactor;
        this.gimg = gimg;
        this.ginfo = ginfo;
        this.gprice = gprice;
        this.fprice = fprice;
        this.gnum = gnum;
        this.synum = synum;
        this.gtime = gtime;
    }

    public GoodsVo() {
    }

    @Override
    public String toString() {
        return "GoodsVo{" +
                "gid=" + gid +
                ", gname='" + gname + '\'' +
                ", gtname='" + gtname + '\'' +
                ", gfactor='" + gfactor + '\'' +
                ", gimg='" + gimg + '\'' +
                ", ginfo='" + ginfo + '\'' +
                ", gprice=" + gprice +
                ", fprice=" + fprice +
                ", gnum=" + gnum +
                ", synum=" + synum +
                ", gtime=" + gtime +
                '}';
    }
}
