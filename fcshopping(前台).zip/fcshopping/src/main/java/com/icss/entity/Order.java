package com.icss.entity;


import java.io.Serializable;
import java.sql.Timestamp;

public class Order implements Serializable {

    private Integer oid; //订单编号
    private String onum; //订单序号
    private Integer uid; //用户编号
    private Timestamp stime;  //提交订单时间
    private Timestamp dtime;  //发货时间
    private double sprice;  //总金额
    private String uinfo;  //买家备注
    private String uaddress;  //买家收货地址
    private String ispay;  //付款 否/是
    private String issend;  //发货 否/是

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public String getOnum() {
        return onum;
    }

    public void setOnum(String onum) {
        this.onum = onum;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Timestamp getStime() {
        return stime;
    }

    public void setStime(Timestamp stime) {
        this.stime = stime;
    }

    public Timestamp getDtime() {
        return dtime;
    }

    public void setDtime(Timestamp dtime) {
        this.dtime = dtime;
    }

    public double getSprice() {
        return sprice;
    }

    public void setSprice(double sprice) {
        this.sprice = sprice;
    }

    public String getUinfo() {
        return uinfo;
    }

    public void setUinfo(String uinfo) {
        this.uinfo = uinfo;
    }

    public String getUaddress() {
        return uaddress;
    }

    public void setUaddress(String uaddress) {
        this.uaddress = uaddress;
    }

    public String getIspay() {
        return ispay;
    }

    public void setIspay(String ispay) {
        this.ispay = ispay;
    }

    public String getIssend() {
        return issend;
    }

    public void setIssend(String issend) {
        this.issend = issend;
    }

    public Order(Integer oid, String onum, Integer uid, Timestamp stime, Timestamp dtime, double sprice, String uinfo, String uaddress, String ispay, String issend) {
        this.oid = oid;
        this.onum = onum;
        this.uid = uid;
        this.stime = stime;
        this.dtime = dtime;
        this.sprice = sprice;
        this.uinfo = uinfo;
        this.uaddress = uaddress;
        this.ispay = ispay;
        this.issend = issend;
    }

    public Order(String onum, Integer uid, Timestamp stime, Timestamp dtime, double sprice, String uinfo, String uaddress, String ispay, String issend) {
        this.onum = onum;
        this.uid = uid;
        this.stime = stime;
        this.dtime = dtime;
        this.sprice = sprice;
        this.uinfo = uinfo;
        this.uaddress = uaddress;
        this.ispay = ispay;
        this.issend = issend;
    }

    public Order(String onum, Integer uid, Timestamp stime, double sprice, String uinfo, String uaddress, String ispay,String issend ) {
        this.onum = onum;
        this.uid = uid;
        this.stime = stime;
        this.sprice = sprice;
        this.uinfo = uinfo;
        this.uaddress = uaddress;
        this.ispay = ispay;
        this.issend=issend;
    }

    public Order() {
    }

    @Override
    public String toString() {
        return "Order{" +
                "oid=" + oid +
                ", onum='" + onum + '\'' +
                ", uid=" + uid +
                ", stime=" + stime +
                ", dtime=" + dtime +
                ", sprice=" + sprice +
                ", unifo='" + uinfo + '\'' +
                ", uaddress='" + uaddress + '\'' +
                ", ispay='" + ispay + '\'' +
                ", issend='" + issend + '\'' +
                '}';
    }
}
