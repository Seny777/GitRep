package com.icss.entity;

import java.sql.Timestamp;
import java.util.Date;

public class User {

    private Integer uid;

    private  String username;

    private String password;

    private  String realname;

    private String sex;

    private String address;

    private String phone;

    private String uaddress;

    private String email;

    private Timestamp regtime;

    public User(Integer uid, String username, String password, String realname, String sex, String address, String phone, String uaddress, String email, Timestamp regtime) {
        this.uid = uid;
        this.username = username;
        this.password = password;
        this.realname = realname;
        this.sex = sex;
        this.address = address;
        this.phone = phone;
        this.uaddress = uaddress;
        this.email = email;
        this.regtime = regtime;
    }

    public User(String username, String password, String realname, String sex, String address, String phone, String uaddress, String email, Timestamp regtime) {
        this.username = username;
        this.password = password;
        this.realname = realname;
        this.sex = sex;
        this.address = address;
        this.phone = phone;
        this.uaddress = uaddress;
        this.email = email;
        this.regtime = regtime;
    }

    @Override
    public String toString() {
        return "User{" +
                "uid=" + uid +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", realname='" + realname + '\'' +
                ", sex=" + sex +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", uaddress='" + uaddress + '\'' +
                ", email='" + email + '\'' +
                ", regtime=" + regtime +
                '}';
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUaddress() {
        return uaddress;
    }

    public void setUaddress(String uaddress) {
        this.uaddress = uaddress;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Timestamp getRegtime() {
        return regtime;
    }

    public void setRegtime(Timestamp regtime) {
        this.regtime = regtime;
    }

    public User() {
    }
}
