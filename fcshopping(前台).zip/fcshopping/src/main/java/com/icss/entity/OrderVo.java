package com.icss.entity;

import java.io.Serializable;
import java.sql.Date;

public class OrderVo implements Serializable {

    private Integer oid;    //订单编号
    private Integer olid;  //订单列表编号
    private String onum;    //订单序号
    private String username;    //用户名称
    private Date stime;     //提交订单时间
    private String gname;    //商品名称
    private Integer olnum;  //商品数量
    private double sprice;  //总金额
    private String unifo;  //买家备注
    private String phone;   //买家联系电话
    private String uaddress;  //买家收货地址
    private String ispay;  //付款 否/是
    private String issend;  //发货 否/是
    private Date dtime;     //发货时间

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public Integer getOlid() {
        return olid;
    }

    public void setOlid(Integer olid) {
        this.olid = olid;
    }

    public String getOnum() {
        return onum;
    }

    public void setOnum(String onum) {
        this.onum = onum;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getStime() {
        return stime;
    }

    public void setStime(Date stime) {
        this.stime = stime;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public Integer getOlnum() {
        return olnum;
    }

    public void setOlnum(Integer olnum) {
        this.olnum = olnum;
    }

    public double getSprice() {
        return sprice;
    }

    public void setSprice(double sprice) {
        this.sprice = sprice;
    }

    public String getUnifo() {
        return unifo;
    }

    public void setUnifo(String unifo) {
        this.unifo = unifo;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUaddress() {
        return uaddress;
    }

    public void setUaddress(String uaddress) {
        this.uaddress = uaddress;
    }

    public String getIspay() {
        return ispay;
    }

    public void setIspay(String ispay) {
        this.ispay = ispay;
    }

    public String getIssend() {
        return issend;
    }

    public void setIssend(String issend) {
        this.issend = issend;
    }

    public Date getDtime() {
        return dtime;
    }

    public void setDtime(Date dtime) {
        this.dtime = dtime;
    }

    public OrderVo(Integer oid,Integer olid, String onum, String username, Date stime, String gname, Integer olnum, double sprice, String unifo, String phone, String uaddress, String ispay, String issend, Date dtime) {
        this.oid=oid;
        this.olid = olid;
        this.onum = onum;
        this.username = username;
        this.stime = stime;
        this.gname = gname;
        this.olnum = olnum;
        this.sprice = sprice;
        this.unifo = unifo;
        this.phone = phone;
        this.uaddress = uaddress;
        this.ispay = ispay;
        this.issend = issend;
        this.dtime = dtime;
    }

    public OrderVo(String onum, String username, Date stime, String gname, Integer olnum, double sprice, String unifo, String phone, String uaddress, String ispay, String issend, Date dtime) {
        this.onum = onum;
        this.username = username;
        this.stime = stime;
        this.gname = gname;
        this.olnum = olnum;
        this.sprice = sprice;
        this.unifo = unifo;
        this.phone = phone;
        this.uaddress = uaddress;
        this.ispay = ispay;
        this.issend = issend;
        this.dtime = dtime;
    }

    public OrderVo() {
    }

    @Override
    public String toString() {
        return "OrderVo{" +
                "olid=" + olid +
                ", onum='" + onum + '\'' +
                ", username=" + username +
                ", stime=" + stime +
                ", gname=" + gname +
                ", olnum=" + olnum +
                ", sprice=" + sprice +
                ", unifo='" + unifo + '\'' +
                ", phone='" + phone + '\'' +
                ", uaddress='" + uaddress + '\'' +
                ", ispay='" + ispay + '\'' +
                ", issend='" + issend + '\'' +
                ", dtime=" + dtime +
                '}';
    }
}
