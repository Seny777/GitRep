package com.icss.entity;

import java.io.Serializable;

public class OrderList implements Serializable {

    private Integer olid;  //订单列表编号
    private Integer oid;    //订单编号
    private Integer gid;    //商品编号
    private Integer olnum;  //商品数量

    public Integer getOlid() {
        return olid;
    }

    public void setOlid(Integer olid) {
        this.olid = olid;
    }

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public Integer getOlnum() {
        return olnum;
    }

    public void setOlnum(Integer olnum) {
        this.olnum = olnum;
    }

    public OrderList(Integer olid, Integer oid, Integer gid, Integer olnum) {
        this.olid = olid;
        this.oid = oid;
        this.gid = gid;
        this.olnum = olnum;
    }

    public OrderList(Integer oid, Integer gid, Integer olnum) {
        this.oid = oid;
        this.gid = gid;
        this.olnum = olnum;
    }

    public OrderList(Integer gid, Integer olnum) {
        this.gid = gid;
        this.olnum = olnum;
    }

    public OrderList() {
    }

    @Override
    public String toString() {
        return "OrderList{" +
                "olid=" + olid +
                ", oid=" + oid +
                ", gid=" + gid +
                ", olnum=" + olnum +
                '}';
    }
}
