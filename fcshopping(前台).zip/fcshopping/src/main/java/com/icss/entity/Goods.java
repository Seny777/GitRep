package com.icss.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class Goods implements Serializable {
    private Integer gid;//商品编号
    private String gname;//商品名称
    private Integer gtid;//商品分类编号
    private String gfactor;//生产厂家
    private String gimg;//商品图片
    private String ginfo;//商品描述
    private double gprice;//商品价格
    private double fprice;//帆成网价格(打折价)
    private Integer gnum;//商品总数量
    private Integer synum;//商品剩余数量
    private Timestamp gtime;//商品上架时间

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public Integer getGtid() {
        return gtid;
    }

    public void setGtid(Integer gtid) {
        this.gtid = gtid;
    }

    public String getGfactor() {
        return gfactor;
    }

    public void setGfactor(String gfactor) {
        this.gfactor = gfactor;
    }

    public String getGimg() {
        return gimg;
    }

    public void setGimg(String gimg) {
        this.gimg = gimg;
    }

    public String getGinfo() {
        return ginfo;
    }

    public void setGinfo(String ginfo) {
        this.ginfo = ginfo;
    }

    public double getGprice() {
        return gprice;
    }

    public void setGprice(double gprice) {
        this.gprice = gprice;
    }

    public double getFprice() {
        return fprice;
    }

    public void setFprice(double fprice) {
        this.fprice = fprice;
    }

    public Integer getGnum() {
        return gnum;
    }

    public void setGnum(Integer gnum) {
        this.gnum = gnum;
    }

    public Integer getSynum() {
        return synum;
    }

    public void setSynum(Integer synum) {
        this.synum = synum;
    }

    public Timestamp getGtime() {
        return gtime;
    }

    public void setGtime(Timestamp gtime) {
        this.gtime = gtime;
    }

    public Goods(Integer gid, String gname, Integer gtid, String gfactor, String gimg, String ginfo, double gprice, double fprice, Integer gnum, Integer synum, Timestamp gtime) {
        this.gid = gid;
        this.gname = gname;
        this.gtid = gtid;
        this.gfactor = gfactor;
        this.gimg = gimg;
        this.ginfo = ginfo;
        this.gprice = gprice;
        this.fprice = fprice;
        this.gnum = gnum;
        this.synum = synum;
        this.gtime = gtime;
    }

    public Goods() {

    }

    public Goods(String gname, Integer gtid, String gfactor, String gimg, String ginfo, double gprice, double fprice, Integer gnum, Integer synum, Timestamp gtime) {
        this.gname = gname;
        this.gtid = gtid;
        this.gfactor = gfactor;
        this.gimg = gimg;
        this.ginfo = ginfo;
        this.gprice = gprice;
        this.fprice = fprice;
        this.gnum = gnum;
        this.synum = synum;
        this.gtime = gtime;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "gid=" + gid +
                ", gname='" + gname + '\'' +
                ", gtid=" + gtid +
                ", gfactor='" + gfactor + '\'' +
                ", gimg='" + gimg + '\'' +
                ", ginfo='" + ginfo + '\'' +
                ", gprice=" + gprice +
                ", fprice=" + fprice +
                ", gnum=" + gnum +
                ", synum=" + synum +
                ", gtime=" + gtime +
                '}';
    }
}
